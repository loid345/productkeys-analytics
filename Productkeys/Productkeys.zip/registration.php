<?php
/**
 * Dart_Productkeys Module Registration
 *
 * @category    Dart
 * @package     Dart_Productkeys
 *
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Dart_Productkeys',
    __DIR__
);
