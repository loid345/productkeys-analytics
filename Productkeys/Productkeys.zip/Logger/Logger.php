<?php
namespace Dart\Productkeys\Logger;

class Logger extends \Monolog\Logger
{
}
?>